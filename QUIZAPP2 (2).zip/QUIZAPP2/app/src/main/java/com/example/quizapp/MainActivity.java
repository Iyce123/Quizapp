package com.example.quizapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView questionTV,questionNumberTv;
    private Button option1Btn,option2Btn,option3Btn,option4Btn;
    private ArrayList<QuizModel> quizModelArrayList;
    Random random;
    int currentScore = 0,questionAttempted = 1, currentPos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        questionTV = findViewById(R.id.idTVQuestion);
        questionNumberTv = findViewById(R.id.idTVQuestionAttempted);
        option1Btn = findViewById(R.id.idBtnOPtion1);
        option2Btn = findViewById(R.id.idBtnOPtion2);
        option3Btn = findViewById(R.id.idBtnOPtion3);
        option4Btn = findViewById(R.id.idBtnOPtion4);
        quizModelArrayList = new ArrayList<>();
        random = new Random();
        getQuizQuestion(quizModelArrayList);
        currentPos = random.nextInt(quizModelArrayList.size());
        setDataToViews(currentPos);
        option1Btn.setOnClickListener(view -> {
            if (quizModelArrayList.get(currentPos).getAnswer().trim().equalsIgnoreCase(option1Btn.getText().toString().trim())){
                currentScore++;
            }
            questionAttempted++;
            currentPos = random.nextInt(quizModelArrayList.size());
            setDataToViews(currentPos);

        });

        option2Btn.setOnClickListener(view -> {
            if (quizModelArrayList.get(currentPos).getAnswer().trim().equalsIgnoreCase(option2Btn.getText().toString().trim())) {
                currentScore++;
            }

            questionAttempted++;
            currentPos = random.nextInt(quizModelArrayList.size());
            setDataToViews(currentPos);
        });
        option3Btn.setOnClickListener(view -> {
            if (quizModelArrayList.get(currentPos).getAnswer().trim().equalsIgnoreCase(option3Btn.getText().toString().trim())){
                currentScore++;
        }

        questionAttempted++;
        currentPos =random.nextInt(quizModelArrayList.size());

        setDataToViews(currentPos);
    });

        option4Btn.setOnClickListener(v -> {
            if (quizModelArrayList.get(currentPos).getAnswer().trim().equalsIgnoreCase(option4Btn.getText().toString().trim())) {
                currentScore++;
            }

            questionAttempted++;
            currentPos = random.nextInt(quizModelArrayList.size());
            setDataToViews(currentPos);
        });

    }

    @SuppressLint("SetTextI18n")
    private void showBottomSheet(){
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog( MainActivity.this);
        View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.score_bottom_sheet, findViewById(R.id.idLLScore));
        TextView scoreTv = bottomSheetView.findViewById(R.id.idTVScore);
        Button restartQuizBtn = bottomSheetView.findViewById(R.id.idBtnRestart);
        scoreTv.setText("Your Score is \n"+ currentScore + "/10");
        restartQuizBtn.setOnClickListener(v -> {
            currentPos = random.nextInt(quizModelArrayList.size());
            setDataToViews(currentPos);
            questionAttempted = 1;
            currentScore = 0;
            bottomSheetDialog.dismiss();
        });
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();

}
    @SuppressLint("SetTextI18n")
    private void setDataToViews(int currentPos) {

        questionNumberTv.setText("Questions Attempted : " + questionAttempted + "/10");
        if (questionAttempted == 10) {
            showBottomSheet();
        } else {

            questionTV.setText(quizModelArrayList.get(currentPos).getQuestion());
            option1Btn.setText(quizModelArrayList.get(currentPos).getOption1());
            option2Btn.setText(quizModelArrayList.get(currentPos).getOption2());
            option3Btn.setText(quizModelArrayList.get(currentPos).getOption3());
            option4Btn.setText(quizModelArrayList.get(currentPos).getOption4());
        }
    }
    private void getQuizQuestion(ArrayList<QuizModel> quizModelArrayList){
        quizModelArrayList.add(new QuizModel("How many countries are in Africa?","20","35","65","54","54"));
        quizModelArrayList.add(new QuizModel("Where would you be if you were standing on the Spanish Steps?","Rome","venice","Chicago","Catalonia","Rome"));
        quizModelArrayList.add(new QuizModel("Who was the Ancient Greek God of the Sun?","Apollo","3Zeus","Hermes","Hades","Apollo"));
        quizModelArrayList.add(new QuizModel("How many elements are in the periodic table?","113","120","118","109","118"));
        quizModelArrayList.add(new QuizModel("What is the world's fastest bird?","Eagle","Peregrine Falcon","Hawk","Gryfalcon","Peregrine Falcon"));
        quizModelArrayList.add(new QuizModel("Who painted the Mona Lisa?","Vincent Van Goph","Leonardo Da Vinci","Claude Monet","Pablo Picasso","Leonardo Da Vinci"));
        quizModelArrayList.add(new QuizModel("What is the biggest state in America?","Texas","Washington","Alaska","Florida","Alaska"));
        quizModelArrayList.add(new QuizModel("Which planet has the most moons?","Mars","Jupiter","Saturn","Venus","Saturn"));
        quizModelArrayList.add(new QuizModel("What country has won the most World Cups?","France","Belgium","Germany","Brazil","Brazil"));
        quizModelArrayList.add(new QuizModel("How many minutes are in a full week?","10,200","8,000","10,800","8,500","10,800"));

    }

}